//
//  AppDelegate.h
//  Digital Leash test 1
//
//  Created by Chad Wiedemann on 7/20/16.
//  Copyright © 2016 TurnToTech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

